"""
Authentication module
"""