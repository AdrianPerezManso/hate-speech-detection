"""
Configuration for the system, the user interface and logging
"""