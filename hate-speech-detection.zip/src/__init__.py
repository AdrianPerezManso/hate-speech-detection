"""
Source package. Contains all the functionality of the system
"""