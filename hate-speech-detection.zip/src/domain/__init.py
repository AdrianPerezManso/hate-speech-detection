"""
Domain classes
"""