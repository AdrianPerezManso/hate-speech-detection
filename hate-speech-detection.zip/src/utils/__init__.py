"""
Utility functions for file management, processing text, validating user inputs and getting statistics
"""