"""
Classifiers module
"""